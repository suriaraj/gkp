# Azure Function entry point
import logging

def main(mytimer) -> None:
    logging.info('Function ran')
