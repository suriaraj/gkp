# variable definitions
