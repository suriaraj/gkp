# Terraform main config for vCME-CloudReaper
variable "subscription_id" {}
variable "tenant_id" {}
variable "resource_group" {}
variable "location" {}
variable "app_settings_file" {}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
  tenant_id       = var.tenant_id
}

locals {
  appsettings = jsondecode(file("${path.module}/appsettings/${var.app_settings_file}"))
}

output "function_app_name" {
  value = local.appsettings.function_app_name
}
