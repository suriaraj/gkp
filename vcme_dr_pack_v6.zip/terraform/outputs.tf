output "hostpool_id" {
  value = module.vcme_hostpool.hostpool_id
}
output "vm_details" {
  value = { for k,v in module.vcme_unit : k => v.vm_ids }
}
