variable "subscription_id" {}
variable "region" {}
variable "resource_group_name" {}
variable "hostpool_name" {}
variable "vm_config" {
  description = "map of region specific configs"
  type = map(object({
    region = string
    subscription_id = string
    vm_count = number
    vm_prefix = string
    image_id = string
    resource_group_name = string
    key_vault_name = string
    des_name = string
  }))
}
