PROD - EUR configuration
