PROD - JPN configuration
