DEV - EUR configuration
