DEV - JPN configuration
