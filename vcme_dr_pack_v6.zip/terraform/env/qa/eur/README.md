QA - EUR configuration
