QA - JPN configuration
