terraform {
  required_version = ">= 1.3.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 3.40.0"
    }
  }
  backend "remote" {}
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
}

module "vcme_hostpool" {
  source = "./modules/vcme_hostpool"
  hostpool_name = var.hostpool_name
  location = var.region
  resource_group_name = var.resource_group_name
}

module "vcme_unit" {
  source = "./modules/vcme_unit"
  for_each = var.vm_config
  region = each.value.region
  subscription_id = each.value.subscription_id
  vm_count = each.value.vm_count
  vm_prefix = each.value.vm_prefix
  image_id = each.value.image_id
  resource_group_name = each.value.resource_group_name
  key_vault_name = each.value.key_vault_name
  des_name = each.value.des_name
}
