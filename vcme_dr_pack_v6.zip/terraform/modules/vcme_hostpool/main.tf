resource "azurerm_virtual_desktop_host_pool" "vcme" {
  name                = var.hostpool_name
  location            = var.location
  resource_group_name = var.resource_group_name
  type                = "Personal"
  friendly_name       = "VCME Host Pool"
  validate_environment = false
}

output "hostpool_id" {
  value = azurerm_virtual_desktop_host_pool.vcme.id
}
