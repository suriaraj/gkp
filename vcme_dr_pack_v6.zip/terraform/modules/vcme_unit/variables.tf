variable "region" {}
variable "subscription_id" {}
variable "vm_count" {}
variable "vm_prefix" {}
variable "image_id" {}
variable "resource_group_name" {}
variable "key_vault_name" {}
variable "des_name" {}
