resource "azurerm_resource_group" "rg" {
  name     = var.resource_group_name
  location = var.region
}

resource "azurerm_key_vault" "kv" {
  name                = var.key_vault_name
  location            = var.region
  resource_group_name = azurerm_resource_group.rg.name
  sku_name            = "standard"
  tenant_id           = "00000000-0000-0000-0000-000000000000"
}

resource "azurerm_disk_encryption_set" "des" {
  name                = var.des_name
  location            = var.region
  resource_group_name = azurerm_resource_group.rg.name
  key_vault_key_id    = azurerm_key_vault.kv.id
}

resource "azurerm_windows_virtual_machine" "vm" {
  count                 = var.vm_count
  name                  = "${var.vm_prefix}${count.index + 1}"
  location              = var.region
  resource_group_name   = azurerm_resource_group.rg.name
  size                  = "Standard_D2s_v3"
  admin_username        = "azureuser"
  admin_password        = "ComplexPass123!"
  source_image_id       = var.image_id
}

output "vm_ids" {
  value = azurerm_windows_virtual_machine.vm[*].id
}
