import csv, json, sys
with open(sys.argv[1], newline='') as f:
    reader = csv.DictReader(f)
    data = {r['region']: {
        "region": r['region'],
        "subscription_id": r['subscription_id'],
        "vm_count": int(r['vm_count']),
        "vm_prefix": r['vm_prefix'],
        "image_id": r['image_id'],
        "resource_group_name": r['resource_group_name'],
        "key_vault_name": r['key_vault_name'],
        "des_name": r['des_name']
    } for r in reader}
    print(json.dumps(data, indent=2))
