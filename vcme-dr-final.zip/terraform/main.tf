locals {
  hostpools = {
    for _, d in var.deployments :
    d.hostpool_name => {
      hostpool_name       = d.hostpool_name
      hostpool_rg_name    = d.hostpool_rg_name
      hostpool_location   = d.hostpool_location
      workspace_name      = d.workspace_name
      workspace_rg_name   = d.workspace_rg_name
      workspace_location  = d.workspace_location
    }
  }
}
module "vcme_hostpool" {
  for_each = local.hostpools
  source   = "./modules/vcme_hostpool"
  tenant_id               = var.tenant_id
  client_id               = var.client_id
  client_secret           = var.client_secret
  hostpool_subscription_id = var.hostpool_subscription_id
  hostpool_name        = each.value.hostpool_name
  hostpool_rg_name     = each.value.hostpool_rg_name
  hostpool_location    = each.value.hostpool_location
  workspace_name       = each.value.workspace_name
  workspace_rg_name    = each.value.workspace_rg_name
  workspace_location   = each.value.workspace_location
}
module "vcme_unit" {
  for_each = var.deployments
  source   = "./modules/vcme_unit"
  tenant_id     = var.tenant_id
  client_id     = var.client_id
  client_secret = var.client_secret
  subscription_id      = each.value.subscription_id
  vm_location          = each.value.vm_location
  resource_group_name  = each.value.resource_group_name
  vnet_name            = each.value.vnet_name
  subnet_name          = each.value.subnet_name
  key_vault_name       = each.value.key_vault_name
  des_name             = each.value.des_name
  hostpool_id          = module.vcme_hostpool[each.value.hostpool_name].hostpool_id
  registration_token   = module.vcme_hostpool[each.value.hostpool_name].registration_token
  vm_prefix            = each.value.vm_prefix
  start_index          = each.value.start_index
  session_host_count   = each.value.session_host_count
  vm_image_id          = each.value.vm_image_id
  user_email           = each.value.user_email
}
