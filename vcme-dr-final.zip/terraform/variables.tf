variable "tenant_id" { description = "Entra ID tenant ID"; type = string }
variable "client_id" { description = "Service principal client ID"; type = string }
variable "client_secret" {
  description = "Service principal client secret"
  type        = string
  sensitive   = true
}
variable "hostpool_subscription_id" {
  description = "Static subscription where all VCME hostpools & VCME workspaces live"
  type        = string
}
variable "deployments" {
  description = "Map of DR deployment rows keyed by ID (row1, row2, ...), generated from Excel/CSV."
  type = map(object({
    subscription_id      = string
    vm_location          = string
    resource_group_name  = string
    vnet_name            = string
    subnet_name          = string
    key_vault_name       = string
    des_name             = string
    hostpool_name        = string
    hostpool_rg_name     = string
    hostpool_location    = string
    workspace_name       = string
    workspace_rg_name    = string
    workspace_location   = string
    vm_prefix            = string
    start_index          = number
    session_host_count   = number
    vm_image_id          = string
    user_email           = string
  }))
}
