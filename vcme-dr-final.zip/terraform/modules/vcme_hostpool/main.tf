provider "azurerm" {
  alias           = "hp"
  features        = {}
  tenant_id       = var.tenant_id
  subscription_id = var.hostpool_subscription_id
  client_id       = var.client_id
  client_secret   = var.client_secret
}
resource "azurerm_resource_group" "hp_rg" {
  provider = azurerm.hp
  name     = var.hostpool_rg_name
  location = var.hostpool_location
}
resource "azurerm_resource_group" "ws_rg" {
  provider = azurerm.hp
  name     = var.workspace_rg_name
  location = var.workspace_location
}
resource "azurerm_virtual_desktop_host_pool" "vcme" {
  provider            = azurerm.hp
  name                = var.hostpool_name
  resource_group_name = azurerm_resource_group.hp_rg.name
  location            = var.hostpool_location
  type                             = "Personal"
  personal_desktop_assignment_type = "Direct"
  preferred_app_group_type         = "Desktop"
  friendly_name            = var.hostpool_name
  maximum_sessions_allowed = 1
  lifecycle { prevent_destroy = true }
}
resource "azurerm_virtual_desktop_application_group" "vcme_dag" {
  provider            = azurerm.hp
  name                = "${var.hostpool_name}-dag"
  resource_group_name = azurerm_resource_group.hp_rg.name
  location            = var.hostpool_location
  type                = "Desktop"
  host_pool_id        = azurerm_virtual_desktop_host_pool.vcme.id
}
resource "azurerm_virtual_desktop_workspace" "vcme_ws" {
  provider            = azurerm.hp
  name                = var.workspace_name
  resource_group_name = azurerm_resource_group.ws_rg.name
  location            = var.workspace_location
  friendly_name       = var.workspace_name
}
resource "azurerm_virtual_desktop_workspace_application_group_association" "ws_dag" {
  provider             = azurerm.hp
  workspace_id         = azurerm_virtual_desktop_workspace.vcme_ws.id
  application_group_id = azurerm_virtual_desktop_application_group.vcme_dag.id
}
resource "azurerm_virtual_desktop_host_pool_registration_info" "reg" {
  provider        = azurerm.hp
  hostpool_id     = azurerm_virtual_desktop_host_pool.vcme.id
  expiration_date = timeadd(timestamp(), "72h")
}
output "hostpool_id" { value = azurerm_virtual_desktop_host_pool.vcme.id }
output "workspace_id" { value = azurerm_virtual_desktop_workspace.vcme_ws.id }
output "registration_token" { value = azurerm_virtual_desktop_host_pool_registration_info.reg.token }
