output "hostpool_id" { value = azurerm_virtual_desktop_host_pool.vcme.id }
output "workspace_id" { value = azurerm_virtual_desktop_workspace.vcme_ws.id }
output "registration_token" { value = azurerm_virtual_desktop_host_pool_registration_info.reg.token }
