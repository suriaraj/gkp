provider "azurerm" {
  alias           = "sub"
  features        = {}
  tenant_id       = var.tenant_id
  subscription_id = var.subscription_id
  client_id       = var.client_id
  client_secret   = var.client_secret
}
data "azuread_user" "user" {
  user_principal_name = var.user_email
}
data "azurerm_client_config" "current" {
  provider = azurerm.sub
}
resource "azurerm_resource_group" "rg" {
  provider = azurerm.sub
  name     = var.resource_group_name
  location = var.vm_location
}
resource "azurerm_virtual_network" "vnet" {
  provider            = azurerm.sub
  name                = var.vnet_name
  address_space       = ["10.0.0.0/16"]
  location            = var.vm_location
  resource_group_name = azurerm_resource_group.rg.name
}
resource "azurerm_subnet" "subnet" {
  provider             = azurerm.sub
  name                 = var.subnet_name
  resource_group_name  = azurerm_resource_group.rg.name
  virtual_network_name = azurerm_virtual_network.vnet.name
  address_prefixes     = ["10.0.1.0/24"]
}
resource "azurerm_key_vault" "kv" {
  provider                    = azurerm.sub
  name                        = var.key_vault_name
  location                    = var.vm_location
  resource_group_name         = azurerm_resource_group.rg.name
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  sku_name                    = "premium"
  enabled_for_disk_encryption = True
  soft_delete_retention_days  = 90
  purge_protection_enabled    = True
  lifecycle { prevent_destroy = true }
}
resource "azurerm_key_vault_access_policy" "sp" {
  provider     = azurerm.sub
  key_vault_id = azurerm_key_vault.kv.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = data.azurerm_client_config.current.object_id
  key_permissions = [
    "Get","List","Create","Update","Delete","Purge",
    "Recover","Backup","Restore","GetRotationPolicy","SetRotationPolicy"
  ]
}
resource "azurerm_key_vault_key" "cmk" {
  provider     = azurerm.sub
  name         = "vcme-cmk-osdisk"
  key_vault_id = azurerm_key_vault.kv.id
  key_type     = "RSA-HSM"
  key_size     = 2048
  depends_on   = [azurerm_key_vault_access_policy.sp]
  lifecycle { prevent_destroy = true }
}
resource "azurerm_disk_encryption_set" "des" {
  provider            = azurerm.sub
  name                = var.des_name
  resource_group_name = azurerm_resource_group.rg.name
  location            = var.vm_location
  key_vault_key_id    = azurerm_key_vault_key.cmk.id
  encryption_type     = "ConfidentialVmEncryptedWithCustomerKey"
  identity { type = "SystemAssigned" }
  lifecycle { prevent_destroy = true }
}
resource "azurerm_key_vault_access_policy" "des_identity" {
  provider     = azurerm.sub
  key_vault_id = azurerm_key_vault.kv.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = azurerm_disk_encryption_set.des.identity[0].principal_id
  key_permissions = ["Get","WrapKey","UnwrapKey"]
}
resource "azurerm_network_interface" "nic" {
  provider            = azurerm.sub
  count               = var.session_host_count
  name                = format("%s-nic-%03d", var.vm_prefix, var.start_index + count.index)
  location            = var.vm_location
  resource_group_name = azurerm_resource_group.rg.name
  ip_configuration {
    name                          = "ipconfig1"
    subnet_id                     = azurerm_subnet.subnet.id
    private_ip_address_allocation = "Dynamic"
  }
}
resource "azurerm_windows_virtual_machine" "vm" {
  provider              = azurerm.sub
  count                 = var.session_host_count
  name                  = format("%s-%03d", var.vm_prefix, var.start_index + count.index)
  location              = var.vm_location
  resource_group_name   = azurerm_resource_group.rg.name
  size                  = "Standard_DC4as_v5"
  admin_username        = "vcmeadmin"
  admin_password        = "ChangeM3Now!"
  network_interface_ids = [azurerm_network_interface.nic[count.index].id]
  provision_vm_agent         = true
  allow_extension_operations = true
  secure_boot_enabled        = true
  vtpm_enabled               = true
  security_type              = "ConfidentialVM"
  license_type               = "Windows_Client"
  os_disk {
    name                   = format("%s-os-%03d", var.vm_prefix, var.start_index + count.index)
    caching                = "ReadWrite"
    storage_account_type   = "Premium_LRS"
    disk_encryption_set_id = azurerm_disk_encryption_set.des.id
  }
  source_image_id = var.vm_image_id
  identity { type = "SystemAssigned" }
}
resource "azurerm_virtual_machine_extension" "vcme_registration" {
  provider                   = azurerm.sub
  count                      = var.session_host_count
  name                       = "VCMERegistration"
  virtual_machine_id         = azurerm_windows_virtual_machine.vm[count.index].id
  publisher                  = "Microsoft.Powershell"
  type                       = "DSC"
  type_handler_version       = "2.73"
  auto_upgrade_minor_version = true
  settings = jsonencode({
    modulesUrl            = "https://wvdportalstorageblob.blob.core.windows.net/galleryartifacts/Configuration_1.0.0.0.zip",
    configurationFunction = "Configuration.ps1\\AddSessionHost",
    properties = {}
  })
  protected_settings = jsonencode({
    registrationInfoToken = var.registration_token
  })
  depends_on = [azurerm_windows_virtual_machine.vm]
}
output "resource_group_name" { value = azurerm_resource_group.rg.name }
output "vm_names" { value = [for v in azurerm_windows_virtual_machine.vm : v.name] }
