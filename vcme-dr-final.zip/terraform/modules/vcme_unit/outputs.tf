output "resource_group_name" { value = azurerm_resource_group.rg.name }
output "vm_names" { value = [for v in azurerm_windows_virtual_machine.vm : v.name] }
