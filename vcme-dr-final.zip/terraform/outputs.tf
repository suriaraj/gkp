output "vcme_hostpools" {
  value = { for k, hp in module.vcme_hostpool : k => {
      hostpool_id  = hp.hostpool_id
      workspace_id = hp.workspace_id
  } }
}
output "vcme_deployments" {
  value = { for k, m in module.vcme_unit : k => {
      resource_group = m.resource_group_name
      vm_names       = m.vm_names
  } }
}
