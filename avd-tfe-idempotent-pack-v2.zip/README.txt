Terraform Enterprise AVD Deployment Template
Version: v2 (Idempotent + Multi-Batch)
--------------------------------------------------
✅ Per-region Key Vault & Disk Encryption Set creation
✅ Skip/reuse existing resources (no overwrite)
✅ Safe multi-batch AVD VM builds
✅ Confidential compute with CMK (DES)
✅ Parallel deployment via GitHub Actions / TFE Workspaces
✅ Supports Excel input (subscription prefix, user email, batch, region, etc.)

Modules:
  - infrastructure/vnet/
  - infrastructure/avd/
  - infrastructure/des/
  - infrastructure/backend/
  - scripts/helpers/

Each batch creates new VMs, keeping older hosts intact.
Key Vaults and DES are created once per region+subscription, with prevent_destroy=true.
