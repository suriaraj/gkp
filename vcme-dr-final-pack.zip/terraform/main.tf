locals {
  first = one(var.deployments)

  shared = {
    hostpool_name      = local.first.hostpool_name
    hostpool_rg_name   = local.first.hostpool_rg_name
    hostpool_location  = local.first.hostpool_location
    workspace_name     = local.first.workspace_name
    workspace_rg_name  = local.first.workspace_rg_name
    workspace_location = local.first.workspace_location
  }
}

module "vcme_hostpool" {
  source = "./modules/vcme_hostpool"

  tenant_id                = var.tenant_id
  client_id                = var.client_id
  client_secret            = var.client_secret
  hostpool_subscription_id = var.hostpool_subscription_id

  hostpool_name      = local.shared.hostpool_name
  hostpool_rg_name   = local.shared.hostpool_rg_name
  hostpool_location  = local.shared.hostpool_location
  workspace_name     = local.shared.workspace_name
  workspace_rg_name  = local.shared.workspace_rg_name
  workspace_location = local.shared.workspace_location
}

module "vcme_unit" {
  for_each = var.deployments
  source   = "./modules/vcme_unit"

  tenant_id     = var.tenant_id
  client_id     = var.client_id
  client_secret = var.client_secret

  subscription_id = each.value.subscription_id
  vm_location     = each.value.vm_location

  resource_group_name = each.value.resource_group_name
  vnet_name           = each.value.vnet_name
  subnet_name         = each.value.subnet_name
  key_vault_name      = each.value.key_vault_name
  des_name            = each.value.des_name

  hostpool_id        = module.vcme_hostpool.hostpool_id
  registration_token = module.vcme_hostpool.registration_token

  vm_prefix          = each.value.vm_prefix
  start_index        = each.value.start_index
  session_host_count = each.value.session_host_count
  vm_image_id        = each.value.vm_image_id
  user_email         = each.value.user_email
}
