variable "tenant_id" {
  type = string
}

variable "client_id" {
  type = string
}

variable "client_secret" {
  type      = string
  sensitive = true
}

variable "hostpool_subscription_id" {
  description = "Static subscription where the single VCME hostpool & workspace live"
  type        = string
}

variable "deployments" {
  description = "Map keyed by row id; values are generated from Excel/CSV."
  type = map(object({
    subscription_id      = string
    vm_location          = string

    resource_group_name  = string
    vnet_name            = string
    subnet_name          = string
    key_vault_name       = string
    des_name             = string

    hostpool_name        = string
    hostpool_rg_name     = string
    hostpool_location    = string

    workspace_name       = string
    workspace_rg_name    = string
    workspace_location   = string

    vm_prefix            = string
    start_index          = number
    session_host_count   = number

    vm_image_id          = string
    user_email           = string
  }))
}
