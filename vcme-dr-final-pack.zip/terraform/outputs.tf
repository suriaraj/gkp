output "vcme_hostpool" {
  value = {
    hostpool_id  = module.vcme_hostpool.hostpool_id
    workspace_id = module.vcme_hostpool.workspace_id
  }
}

output "vcme_deployments" {
  value = {
    for k, m in module.vcme_unit :
    k => {
      resource_group = m.resource_group_name
      vm_names       = m.vm_names
    }
  }
}
