variable "tenant_id" {
  type = string
}

variable "client_id" {
  type = string
}

variable "client_secret" {
  type      = string
  sensitive = true
}

variable "hostpool_subscription_id" {
  type = string
}

variable "hostpool_name" {
  type = string
}

variable "hostpool_rg_name" {
  type = string
}

variable "hostpool_location" {
  type = string
}

variable "workspace_name" {
  type = string
}

variable "workspace_rg_name" {
  type = string
}

variable "workspace_location" {
  type = string
}
