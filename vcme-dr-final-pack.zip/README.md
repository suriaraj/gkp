VCME DR Final Pack

- Single global VCME hostpool + workspace + DAG in hostpool_subscription_id.
- All session hosts (multi-sub, multi-region) attach to this hostpool.
- vm_prefix is used as-is:
  - Use vcmemicdr or vcmemaedr to mark DR hosts.
  - Names look like vcmemicdr001, vcmemicdr002, etc.
- Excel/CSV-driven:
  - See excel/vcme-deployments-template.csv.
  - Use tools/excel_to_tfvars.py to generate deployments.tfvars.
- Terraform entrypoint:
  - terraform/main.tf with modules/vcme_hostpool and modules/vcme_unit.
