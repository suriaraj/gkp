import csv
import sys
from pathlib import Path

def main(csv_path, tfvars_path):
    deployments = {}
    with open(csv_path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            row_id = row["row_id"].strip()
            if not row_id:
                continue
            deployments[row_id] = {
                "subscription_id":      row["subscription_id"].strip(),
                "vm_location":          row["vm_location"].strip(),
                "resource_group_name":  row["resource_group_name"].strip(),
                "vnet_name":            row["vnet_name"].strip(),
                "subnet_name":          row["subnet_name"].strip(),
                "key_vault_name":       row["key_vault_name"].strip(),
                "des_name":             row["des_name"].strip(),
                "hostpool_name":        row["hostpool_name"].strip(),
                "hostpool_rg_name":     row["hostpool_rg_name"].strip(),
                "hostpool_location":    row["hostpool_location"].strip(),
                "workspace_name":       row["workspace_name"].strip(),
                "workspace_rg_name":    row["workspace_rg_name"].strip(),
                "workspace_location":   row["workspace_location"].strip(),
                "vm_prefix":            row["vm_prefix"].strip(),
                "start_index":          int(row["start_index"]),
                "session_host_count":   int(row["session_host_count"]),
                "vm_image_id":          row["vm_image_id"].strip(),
                "user_email":           row["user_email"].strip()
            }

    out = Path(tfvars_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as f:
        f.write("deployments = {\n")
        for key, vals in deployments.items():
            f.write(f"  {key} = {{\n")
            for k, v in vals.items():
                if isinstance(v, int):
                    f.write(f"    {k} = {v}\n")
                else:
                    f.write(f"    {k} = \"{v}\"\n")
            f.write("  }\n")
        f.write("}\n")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: excel_to_tfvars.py <input.csv> <output.tfvars>")
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
