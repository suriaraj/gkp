import os, importlib
mod = importlib.import_module("ib_cleanup_timer.__init__")

class Env:
    def __init__(self, env): self.env=env; self.old={}
    def __enter__(self):
        for k,v in self.env.items(): self.old[k]=os.environ.get(k); os.environ[k]=v
    def __exit__(self, a,b,c):
        for k in self.env:
            if self.old[k] is None: os.environ.pop(k, None)
            else: os.environ[k]=self.old[k]

def test_default_naming_any_suffix():
    for vm in ["avdmaehp1-0","avdmaehp1-00","avdmaehp1-123"]:
        nic, disk = mod.compute_dep_names(vm)
        base, suf = vm.rsplit("-", 1)
        assert nic == f"{base}-nic-{suf}"
        assert disk == f"{base}-osdisk-{suf}"

def test_custom_templates():
    with Env({"NAME_SUFFIX_REGEX": r"^(.*?)-(\d+)$", "NIC_FORMAT": "{base}_NIC_{suffix}", "OSDISK_FORMAT": "{base}_DISK_{suffix}"}):
        nic, disk = mod.compute_dep_names("avdmichp1-45")
        assert nic == "avdmichp1_NIC_45" and disk == "avdmichp1_DISK_45"

def test_no_suffix_fallback():
    with Env({"NAME_SUFFIX_REGEX": r"^(.*?)-(\d+)$", "NIC_FORMAT": "{base}-nic{suffix}", "OSDISK_FORMAT": "{base}-osdisk{suffix}"}):
        nic, disk = mod.compute_dep_names("avdmaehp1")
        assert nic == "avdmaehp1-nic" and disk == "avdmaehp1-osdisk"
