variable "tfe_hostname"     { type = string }
variable "tfe_organization" { type = string }
variable "workspace_name"   { type = string }

variable "tenant_id"        { type = string, default = null }
variable "subscription_id"  { type = string }
variable "client_id"        { type = string, default = env("ARM_CLIENT_ID") }
variable "client_secret"    { type = string, sensitive = true, default = env("ARM_CLIENT_SECRET") }

variable "location"         { type = string }
variable "target_user_email"{ type = string }

variable "resource_group_name" { type = string, default = null }
variable "prefix"              { type = string, default = "avd" }
variable "vm_size"             { type = string, default = "Standard_DC4as_v5" }
variable "session_host_count"  { type = number, default = 2 }
variable "image_offer"         { type = string, default = "windows-11" }
variable "image_sku"           { type = string, default = "win11-23h2-ent" }

variable "cmk_kv_name"  { type = string, default = null }
variable "cmk_key_name" { type = string, default = "cmk-osdisk" }
