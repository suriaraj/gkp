output "workspace_name"    { value = var.workspace_name }
output "resource_group"    { value = module.avd.resource_group_name }
output "host_pool_id"      { value = module.avd.host_pool_id }
output "workspace_id"      { value = module.avd.workspace_id }
output "app_group_id"      { value = module.avd.app_group_id }
output "disk_encryption_set_id" { value = module.avd.disk_encryption_set_id }
output "cmk_vault_uri"     { value = module.avd.cmk_vault_uri }
output "cmk_key_id"        { value = module.avd.cmk_key_id }
