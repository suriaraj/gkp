locals {
  rg_name = coalesce(var.resource_group_name, "${var.prefix}-${replace(var.location, "/\\W+/", "")}")
}

module "avd" {
  source                = "./modules/avd"
  prefix                = var.prefix
  location              = var.location
  resource_group_name   = local.rg_name

  subscription_id       = var.subscription_id
  target_user_email     = var.target_user_email

  vm_size               = var.vm_size
  session_host_count    = var.session_host_count
  image_offer           = var.image_offer
  image_sku             = var.image_sku

  cmk_kv_name           = var.cmk_kv_name
  cmk_key_name          = var.cmk_key_name
}
