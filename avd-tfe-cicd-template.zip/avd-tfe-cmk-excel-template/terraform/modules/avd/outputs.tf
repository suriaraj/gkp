output "resource_group_name" { value = azurerm_resource_group.this.name }
output "host_pool_id"       { value = azurerm_virtual_desktop_host_pool.this.id }
output "workspace_id"       { value = azurerm_virtual_desktop_workspace.ws.id }
output "app_group_id"       { value = azurerm_virtual_desktop_application_group.dag.id }
output "disk_encryption_set_id" { value = azurerm_disk_encryption_set.des.id }
output "cmk_vault_uri"      { value = azurerm_key_vault.kv.vault_uri }
output "cmk_key_id"         { value = azurerm_key_vault_key.cmk.id }
