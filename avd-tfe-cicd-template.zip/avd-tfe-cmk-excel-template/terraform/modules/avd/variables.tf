variable "prefix"              { type = string }
variable "location"            { type = string }
variable "resource_group_name" { type = string }

variable "subscription_id"     { type = string }
variable "target_user_email"   { type = string }

variable "vm_size"             { type = string }
variable "session_host_count"  { type = number }
variable "image_offer"         { type = string }
variable "image_sku"           { type = string }

variable "cmk_kv_name"             { type = string, default = null }
variable "cmk_key_name"            { type = string, default = "cmk-osdisk" }
variable "cmk_enable_purge_protection" { type = bool, default = true }
variable "cmk_soft_delete_days"    { type = number, default = 90 }
