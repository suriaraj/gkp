data "azurerm_client_config" "current" {}

resource "azurerm_resource_group" "this" {
  name     = var.resource_group_name
  location = var.location
}

# Host Pool
resource "azurerm_virtual_desktop_host_pool" "this" {
  name                = "${var.prefix}-hp"
  location            = azurerm_resource_group.this.location
  resource_group_name = azurerm_resource_group.this.name

  type                       = "Pooled"
  load_balancer_type         = "BreadthFirst"
  preferred_app_group_type   = "Desktop"
  maximum_sessions_allowed   = 16
  validate_environment       = true
  start_vm_on_connect        = true
}

resource "azurerm_virtual_desktop_host_pool_registration_info" "reg" {
  hostpool_id     = azurerm_virtual_desktop_host_pool.this.id
  expiration_date = timeadd(timestamp(), "24h")
}

resource "azurerm_virtual_desktop_application_group" "dag" {
  name                = "${var.prefix}-dag"
  location            = azurerm_resource_group.this.location
  resource_group_name = azurerm_resource_group.this.name
  type                = "Desktop"
  host_pool_id        = azurerm_virtual_desktop_host_pool.this.id
}

resource "azurerm_virtual_desktop_workspace" "ws" {
  name                = "${var.prefix}-ws"
  location            = azurerm_resource_group.this.location
  resource_group_name = azurerm_resource_group.this.name
}

resource "azurerm_virtual_desktop_workspace_application_group_association" "assoc" {
  workspace_id         = azurerm_virtual_desktop_workspace.ws.id
  application_group_id = azurerm_virtual_desktop_application_group.dag.id
}

# Resolve user by email
data "azuread_user" "target" {
  user_principal_name = var.target_user_email
}

data "azurerm_role_definition" "dv_user" {
  name  = "Desktop Virtualization User"
  scope = azurerm_virtual_desktop_application_group.dag.id
}

resource "azurerm_role_assignment" "grant" {
  scope              = azurerm_virtual_desktop_application_group.dag.id
  role_definition_id = data.azurerm_role_definition.dv_user.role_definition_id
  principal_id       = data.azuread_user.target.object_id
  principal_type     = "User"
}

# Networking (minimal)
resource "azurerm_network_security_group" "nsg" {
  name                = "${var.prefix}-nsg"
  location            = azurerm_resource_group.this.location
  resource_group_name = azurerm_resource_group.this.name
}

resource "azurerm_virtual_network" "vnet" {
  name                = "${var.prefix}-vnet"
  address_space       = ["10.20.0.0/16"]
  location            = azurerm_resource_group.this.location
  resource_group_name = azurerm_resource_group.this.name
}

resource "azurerm_subnet" "subnet" {
  name                 = "sessionhosts"
  resource_group_name  = azurerm_resource_group.this.name
  virtual_network_name = azurerm_virtual_network.vnet.name
  address_prefixes     = ["10.20.1.0/24"]
  service_endpoints    = ["Microsoft.Storage"]
}

resource "azurerm_network_interface" "nic" {
  count               = var.session_host_count
  name                = "${var.prefix}-nic-${count.index}"
  location            = azurerm_resource_group.this.location
  resource_group_name = azurerm_resource_group.this.name

  ip_configuration {
    name                          = "ipconfig1"
    subnet_id                     = azurerm_subnet.subnet.id
    private_ip_address_allocation = "Dynamic"
  }
}

# Key Vault for CMK
resource "azurerm_key_vault" "kv" {
  name                        = coalesce(var.cmk_kv_name, "${var.prefix}-kv")
  location                    = azurerm_resource_group.this.location
  resource_group_name         = azurerm_resource_group.this.name
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  sku_name                    = "standard"
  soft_delete_retention_days  = var.cmk_soft_delete_days
  purge_protection_enabled    = var.cmk_enable_purge_protection
  enable_rbac_authorization   = false
}

resource "azurerm_key_vault_access_policy" "me" {
  key_vault_id = azurerm_key_vault.kv.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = data.azurerm_client_config.current.object_id

  key_permissions = [
    "Get","List","Create","Update","Delete","Purge","Recover","Backup","Restore","GetRotationPolicy","SetRotationPolicy"
  ]
}

resource "azurerm_key_vault_key" "cmk" {
  name         = var.cmk_key_name
  key_vault_id = azurerm_key_vault.kv.id
  key_type     = "RSA"
  key_size     = 3072
  depends_on   = [azurerm_key_vault_access_policy.me]
}

resource "azurerm_disk_encryption_set" "des" {
  name                = "${var.prefix}-des"
  resource_group_name = azurerm_resource_group.this.name
  location            = azurerm_resource_group.this.location
  key_vault_key_id    = azurerm_key_vault_key.cmk.id
  identity { type = "SystemAssigned" }
}

resource "azurerm_key_vault_access_policy" "des" {
  key_vault_id = azurerm_key_vault.kv.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = azurerm_disk_encryption_set.des.identity[0].principal_id
  key_permissions = ["Get","WrapKey","UnwrapKey"]
}

resource "random_password" "vm" {
  length  = 20
  special = true
}

resource "azurerm_windows_virtual_machine" "session" {
  count               = var.session_host_count
  name                = "${var.prefix}-vm-${count.index}"
  location            = azurerm_resource_group.this.location
  resource_group_name = azurerm_resource_group.this.name
  size                = var.vm_size
  admin_username      = "avdadmin"
  admin_password      = random_password.vm.result
  network_interface_ids = [azurerm_network_interface.nic[count.index].id]

  # Confidential Compute
  secure_boot_enabled = true
  vtpm_enabled        = true
  security_type       = "ConfidentialVM"

  os_disk {
    caching                    = "ReadWrite"
    storage_account_type       = "Premium_LRS"
    security_encryption_type   = "VMGuestStateOnly"
    disk_encryption_set_id     = azurerm_disk_encryption_set.des.id
  }

  source_image_reference {
    publisher = "microsoftwindowsdesktop"
    offer     = var.image_offer
    sku       = var.image_sku
    version   = "latest"
  }

  depends_on = [azurerm_key_vault_access_policy.des]
}

# Register session hosts to AVD
resource "azurerm_virtual_machine_extension" "register" {
  count                = var.session_host_count
  name                 = "AVDRegistration"
  virtual_machine_id   = azurerm_windows_virtual_machine.session[count.index].id
  publisher            = "Microsoft.Azure.VirtualDesktop"
  type                 = "Agent"
  type_handler_version = "1.0"

  settings = jsonencode({
    "HostPoolName"        : azurerm_virtual_desktop_host_pool.this.name,
    "RegistrationInfoToken": azurerm_virtual_desktop_host_pool_registration_info.reg.token
  })
}
