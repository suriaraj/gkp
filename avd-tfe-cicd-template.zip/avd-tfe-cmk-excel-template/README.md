# AVD + Terraform Enterprise CI/CD (Excel/CSV-driven) with Confidential VMs and CMK (DES)

This repo deploys Azure Virtual Desktop via Terraform, using Terraform Enterprise as the remote backend, and fans out **in parallel** per target (subscription + user email + region). Session host OS disks are encrypted with a **customer-managed key** via a **Disk Encryption Set**, and VMs are configured for **Confidential Compute**.

## Inputs
- Preferred: `env/targets.xlsx` (sheet `targets` with columns: `name, subscription_id, user_email, region`)
- Fallback: `env/targets.csv` with the same headers (included here as an example).

The GitHub Actions workflow automatically tries Excel first (installing `pandas + openpyxl`), then falls back to CSV.

## Secrets / Variables (Repository Settings)
- **Secrets**
  - `ARM_CLIENT_ID`, `ARM_CLIENT_SECRET`, `ARM_TENANT_ID` (Azure App registration / Service Principal)
  - `TFE_TOKEN` (Terraform Cloud/Enterprise token)
- **Variables**
  - `TFE_HOSTNAME` (e.g., `app.terraform.io` or your private TFE host)
  - `TFE_ORG` (your org)
  - `WORKSPACE_PREFIX` (optional, default `avd`)

## Run
- Push to `main` or trigger the workflow manually. Each row in the input becomes one parallel job and one isolated TFE workspace.

## Notes
- Ensure your SP has rights to create Key Vault/Key/DES and role assignments.
- Adjust image offer/SKU and VM size if your region requires different AVD-capable Confidential VM settings.
