# VCME DR Terraform + TFE Template

This is a **template** repo that mirrors the layout and logic discussed in ChatGPT.
It is *not* your exact corporate code, but a clean starting point:

- CSV + Python to generate `deployments.auto.tfvars`
- Terraform root using:
  - TFE/Terraform Cloud backend (configured via backend.tfbackend files)
  - Shared VCME DR hostpool/workspace module
  - Per-subscription VCME unit module for DR virtual machines
- GitHub Actions workflow for plan on `dev` / `qa`.

You must adapt:
- Provider auth (service principal / managed identity)
- Any internal module sources (e.g. `terraform.xom.cloud/...`)
- Actual AVD configuration, NSGs, Key Vault references, etc.
