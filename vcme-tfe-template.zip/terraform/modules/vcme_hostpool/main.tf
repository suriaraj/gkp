terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.42.0"
    }
  }
}

resource "azurerm_resource_group" "hostpool" {
  name     = var.vcme_hostpool_rg
  location = var.vcme_hostpool_loc
}

resource "azurerm_resource_group" "workspace" {
  name     = var.vcme_workspace_rg
  location = var.vcme_workspace_loc
}

resource "azurerm_virtual_desktop_host_pool" "vcme" {
  name                = var.vcme_hostpool_name
  location            = azurerm_resource_group.hostpool.location
  resource_group_name = azurerm_resource_group.hostpool.name
  type                = "Pooled"
  load_balancer_type  = "BreadthFirst"
  maximum_sessions_allowed = 16
  preferred_app_group_type = "Desktop"
  personal_desktop_assignment_type = "Automatic"
}

resource "azurerm_virtual_desktop_workspace" "vcme" {
  name                = var.vcme_workspace_name
  location            = azurerm_resource_group.workspace.location
  resource_group_name = azurerm_resource_group.workspace.name
}

resource "azurerm_virtual_desktop_application_group" "vcme" {
  name                = "${var.vcme_hostpool_name}-DAG"
  location            = azurerm_virtual_desktop_host_pool.vcme.location
  resource_group_name = azurerm_resource_group.hostpool.name
  type                = "Desktop"
  host_pool_id        = azurerm_virtual_desktop_host_pool.vcme.id
}

resource "azurerm_virtual_desktop_workspace_application_group_association" "vcme" {
  workspace_id         = azurerm_virtual_desktop_workspace.vcme.id
  application_group_id = azurerm_virtual_desktop_application_group.vcme.id
}

resource "azurerm_virtual_desktop_host_pool_registration_info" "vcme" {
  host_pool_id    = azurerm_virtual_desktop_host_pool.vcme.id
  expiration_date = timeadd(timestamp(), "72h")
}
