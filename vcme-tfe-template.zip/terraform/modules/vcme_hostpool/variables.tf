variable "tenant_id" {
  type = string
}

variable "vcme_hostpool_name" {
  type = string
}

variable "vcme_hostpool_rg" {
  type = string
}

variable "vcme_hostpool_loc" {
  type = string
}

variable "vcme_workspace_name" {
  type = string
}

variable "vcme_workspace_rg" {
  type = string
}

variable "vcme_workspace_loc" {
  type = string
}
