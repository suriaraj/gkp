variable "tenant_id" {
  description = "Azure AD tenant id"
  type        = string
}

variable "vcme_hostpool_name" {
  type = string
}
variable "vcme_hostpool_rg_name" {
  type = string
}
variable "vcme_hostpool_location" {
  type = string
}
variable "vcme_workspace_name" {
  type = string
}
variable "vcme_workspace_rg_name" {
  type = string
}
variable "vcme_workspace_location" {
  type = string
}

variable "hostpool_subscription_id" {
  description = "Subscription id hosting the shared VCME DR hostpool"
  type        = string
}

variable "subscription_ids" {
  description = "Map of subscription alias -> subscription id"
  type        = map(string)
}

resource "random_password" "admin" {
  length           = 24
  special          = true
  override_special = "!#$%&()*-_=+[]{}<>:?/"
}

output "admin_password" {
  value     = random_password.admin.result
  sensitive = true
}

variable "admin_password" {
  description = "Admin password for session hosts (if empty, generated)"
  type        = string
  default     = ""
}

locals {
  effective_admin_password = length(var.admin_password) > 0 ? var.admin_password : random_password.admin.result
}

variable "deployments" {
  description = "Excel-driven DR deployments configuration"
  type = map(object({
    subscription_alias  = string
    subscription_id     = string
    primary_code        = string
    business_unit       = string
    vm_location         = string
    resource_group_name = string
    vnet_name           = string
    subnet_name         = string
    key_vault_name      = string
    des_name            = string
    vm_prefix           = string
    start_index         = number
    session_host_count  = number
    vm_image_id         = string
    user_email          = string
    admin_password      = string
  }))
}
