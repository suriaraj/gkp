terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.42.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }
}

provider "azurerm" {
  features {}
  tenant_id       = var.tenant_id
  subscription_id = var.hostpool_subscription_id
}

provider "azurerm" {
  alias           = "mic"
  features        {}
  tenant_id       = var.tenant_id
  subscription_id = lookup(var.subscription_ids, "mic", null)
}

provider "azurerm" {
  alias           = "mae"
  features        {}
  tenant_id       = var.tenant_id
  subscription_id = lookup(var.subscription_ids, "mae", null)
}
