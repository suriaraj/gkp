terraform {
  backend "remote" {}
}

locals {
  dep_mic = { for k, v in var.deployments : k => v if v.subscription_alias == "mic" }
  dep_mae = { for k, v in var.deployments : k => v if v.subscription_alias == "mae" }
}

module "vcme_hostpool" {
  source               = "./modules/vcme_hostpool"
  providers            = { azurerm = azurerm }
  tenant_id            = var.tenant_id
  vcme_hostpool_name   = var.vcme_hostpool_name
  vcme_hostpool_rg     = var.vcme_hostpool_rg_name
  vcme_hostpool_loc    = var.vcme_hostpool_location
  vcme_workspace_name  = var.vcme_workspace_name
  vcme_workspace_rg    = var.vcme_workspace_rg_name
  vcme_workspace_loc   = var.vcme_workspace_location
}

module "vcme_unit_mic" {
  for_each          = local.dep_mic
  source            = "./modules/vcme_unit"
  providers         = { azurerm = azurerm.mic }

  tenant_id         = var.tenant_id
  subscription_id   = each.value.subscription_id
  vm_location       = each.value.vm_location
  resource_group_name = each.value.resource_group_name
  vnet_name         = each.value.vnet_name
  subnet_name       = each.value.subnet_name
  key_vault_name    = each.value.key_vault_name
  des_name          = each.value.des_name
  vm_prefix         = each.value.vm_prefix
  start_index       = each.value.start_index
  session_host_count = each.value.session_host_count
  vm_image_id       = each.value.vm_image_id
  user_email        = each.value.user_email
  hostpool_id        = module.vcme_hostpool.hostpool_id
  registration_token = module.vcme_hostpool.registration_token
  admin_password     = each.value.admin_password
  network_security_group_id = "" # placeholder, actual NSG created in module
}

module "vcme_unit_mae" {
  for_each          = local.dep_mae
  source            = "./modules/vcme_unit"
  providers         = { azurerm = azurerm.mae }

  tenant_id         = var.tenant_id
  subscription_id   = each.value.subscription_id
  vm_location       = each.value.vm_location
  resource_group_name = each.value.resource_group_name
  vnet_name         = each.value.vnet_name
  subnet_name       = each.value.subnet_name
  key_vault_name    = each.value.key_vault_name
  des_name          = each.value.des_name
  vm_prefix         = each.value.vm_prefix
  start_index       = each.value.start_index
  session_host_count = each.value.session_host_count
  vm_image_id       = each.value.vm_image_id
  user_email        = each.value.user_email
  hostpool_id        = module.vcme_hostpool.hostpool_id
  registration_token = module.vcme_hostpool.registration_token
  admin_password     = each.value.admin_password
  network_security_group_id = "" # placeholder
}

output "vcme_hostpool_id" {
  value = module.vcme_hostpool.hostpool_id
}

output "vcme_registration_token" {
  value     = module.vcme_hostpool.registration_token
  sensitive = true
}
