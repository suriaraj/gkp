# vcme AVD DR Terraform Pack

This pack includes:
- GitHub Actions workflow for matrix fan-out from Excel/CSV.
- Per-subscription + per-region deployment:
  - RG: `vcme-<sub_prefix>-<locShort>-dr-rg`
  - VNet: `vcme-<sub_prefix>-<locShort>-vn`
  - Subnet: `sn`
  - Key Vault: unique `vcme<sub_prefix><locShort>drkv` (premium, CMK)
  - DES: `vcme-<sub_prefix>-<locShort>-dr-des`
- Confidential AVD session hosts:
  - VM name base: `vcme<locShort>dr<batch>` so new batches do not overwrite.
  - Uses CMK-backed DES for OS disks.
  - AVD registration & AAD login via extensions.
- Workspace name is exactly the `name` column (no prefix).

Edit env/targets.csv or env/targets.xlsx with one row per deployment.
