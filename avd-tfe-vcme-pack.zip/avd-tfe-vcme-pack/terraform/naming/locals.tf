locals {
  loc_short_map = {
    "japan_east"    = "jpn"
    "japan_west"    = "jpw"
    "centralindia"  = "cin"
    "westeurope"    = "weu"
    "northeurope"   = "neu"
    "eastus"        = "eus"
    "eastus2"       = "eus2"
    "westus3"       = "wus3"
    "uksouth"       = "uks"
    "southeastasia" = "sea"
  }

  loc_norm   = lower(replace(var.location, " ", ""))
  loc_short  = lookup(local.loc_short_map, local.loc_norm, local.loc_norm)
  dr_suffix  = var.dr_mode ? "-dr" : ""

  # DR naming, custom VCME -> vcme to distinguish from existing prod/DR
  rg_name     = "vcme-${var.subscription_prefix}-${local.loc_short}${local.dr_suffix}-rg"
  vnet_name   = "vcme-${var.subscription_prefix}-${local.loc_short}-vn"
  subnet_name = "sn"

  # KV / DES names: unique to avoid VCME-<REG>-POL-*; no dashes for KV
  kv_base     = lower("vcme${var.subscription_prefix}${local.loc_short}drkv")
  kv_name     = substr(local.kv_base, 0, 24)

  des_name    = "vcme-${var.subscription_prefix}-${local.loc_short}-dr-des"

  # VM base includes batch so multiple batches don't collide
  vm_base     = "vcme${local.loc_short}dr${var.batch}"
}

output "loc_short"   { value = local.loc_short }
output "rg_name"     { value = local.rg_name }
output "vnet_name"   { value = local.vnet_name }
output "subnet_name" { value = local.subnet_name }
output "kv_name"     { value = local.kv_name }
output "des_name"    { value = local.des_name }
output "vm_base"     { value = local.vm_base }
