terraform {
  required_version = ">= 1.5.0"
  required_providers {
    azurerm = { source = "hashicorp/azurerm", version = "~> 3.116" }
    azuread = { source = "hashicorp/azuread", version = "~> 2.50" }
  }
  # Overridden in pipeline with -backend-config
  backend "remote" {
    hostname     = "app.terraform.io"
    organization = "CHANGE_ME"
    workspaces {
      name = "CHANGE_ME"
    }
  }
}

provider "azurerm" {
  features {}
  tenant_id       = var.tenant_id
  subscription_id = var.subscription_id
  client_id       = var.client_id
  client_secret   = var.client_secret
}

provider "azuread" {
  tenant_id = var.tenant_id
}
