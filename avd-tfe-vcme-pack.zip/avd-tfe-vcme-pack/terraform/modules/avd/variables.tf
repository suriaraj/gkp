variable "prefix"             { type = string }
variable "dr_mode"            { type = bool }
variable "hostpool_name"      { type = string }

variable "location"           { type = string }
variable "resource_group_name"{ type = string }
variable "subscription_id"    { type = string }

variable "subnet_id"          { type = string }
variable "des_id"             { type = string }

variable "vm_base"            { type = string }
variable "vm_size"            { type = string }
variable "session_host_count" { type = number }

variable "image_publisher"    { type = string }
variable "image_offer"        { type = string }
variable "image_sku"          { type = string }

variable "intune_join"        { type = bool }
variable "target_user_email"  { type = string }

variable "admin_username"     { type = string }
variable "admin_password"     { type = string, sensitive = true }
