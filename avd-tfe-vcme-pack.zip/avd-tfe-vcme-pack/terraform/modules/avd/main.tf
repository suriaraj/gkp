data "azurerm_client_config" "current" {}

# Host pool
resource "azurerm_virtual_desktop_host_pool" "host_pool" {
  name                = var.hostpool_name
  location            = var.location
  resource_group_name = var.resource_group_name

  type                     = "Pooled"
  load_balancer_type       = "BreadthFirst"
  preferred_app_group_type = "Desktop"
  maximum_sessions_allowed = 16
  validate_environment     = true
  start_vm_on_connect      = true
}

resource "azurerm_virtual_desktop_host_pool_registration_info" "registration" {
  hostpool_id     = azurerm_virtual_desktop_host_pool.host_pool.id
  expiration_date = timeadd(timestamp(), "72h")
}

# App group + workspace
resource "azurerm_virtual_desktop_application_group" "app_group" {
  name                = "${var.prefix}-dag"
  location            = var.location
  resource_group_name = var.resource_group_name
  type                = "Desktop"
  host_pool_id        = azurerm_virtual_desktop_host_pool.host_pool.id
}

resource "azurerm_virtual_desktop_workspace" "workspace" {
  name                = "${var.prefix}-ws"
  location            = var.location
  resource_group_name = var.resource_group_name
}

resource "azurerm_virtual_desktop_workspace_application_group_association" "assoc" {
  workspace_id         = azurerm_virtual_desktop_workspace.workspace.id
  application_group_id = azurerm_virtual_desktop_application_group.app_group.id
}

# Assign Desktop Virtualization User to target user
data "azuread_user" "target" {
  user_principal_name = var.target_user_email
}

data "azurerm_role_definition" "dv_user" {
  name  = "Desktop Virtualization User"
  scope = azurerm_virtual_desktop_application_group.app_group.id
}

resource "azurerm_role_assignment" "rbac_assignment" {
  scope              = azurerm_virtual_desktop_application_group.app_group.id
  role_definition_id = data.azurerm_role_definition.dv_user.role_definition_id
  principal_id       = data.azuread_user.target.object_id
  principal_type     = "User"
}

# NICs
resource "azurerm_network_interface" "session_host_nic" {
  count               = var.session_host_count
  name                = "${var.vm_base}-nic-${count.index}"
  location            = var.location
  resource_group_name = var.resource_group_name

  ip_configuration {
    name                          = "ipconfig1"
    subnet_id                     = var.subnet_id
    private_ip_address_allocation = "Dynamic"
  }
}

# Confidential VMs
resource "azurerm_windows_virtual_machine" "confidential_avd" {
  count                 = var.session_host_count
  name                  = "${var.vm_base}-${count.index}"
  location              = var.location
  resource_group_name   = var.resource_group_name
  size                  = var.vm_size

  admin_username        = var.admin_username
  admin_password        = var.admin_password

  network_interface_ids = [azurerm_network_interface.session_host_nic[count.index].id]

  provision_vm_agent         = true
  allow_extension_operations = true
  secure_boot_enabled        = true
  vtpm_enabled               = true
  security_type              = "ConfidentialVM"
  license_type               = "Windows_Client"

  os_disk {
    name                   = "${var.vm_base}-osdisk-${count.index}"
    caching                = "ReadWrite"
    storage_account_type   = "Premium_LRS"
    disk_encryption_set_id = var.des_id
  }

  source_image_reference {
    publisher = var.image_publisher
    offer     = var.image_offer
    sku       = var.image_sku
    version   = "latest"
  }

  identity {
    type = "SystemAssigned"
  }
}

# Guest Attestation
resource "azurerm_virtual_machine_extension" "guest_attestation" {
  count                      = var.session_host_count
  name                       = "GuestAttestationAgent"
  virtual_machine_id         = azurerm_windows_virtual_machine.confidential_avd[count.index].id
  publisher                  = "Microsoft.Azure.Security.WindowsAttestation"
  type                       = "GuestAttestation"
  type_handler_version       = "1.0"
  auto_upgrade_minor_version = true
}

# AVD registration via DSC
resource "azurerm_virtual_machine_extension" "avd_reg" {
  count                      = var.session_host_count
  name                       = "AVDRegistration"
  virtual_machine_id         = azurerm_windows_virtual_machine.confidential_avd[count.index].id
  publisher                  = "Microsoft.Powershell"
  type                       = "DSC"
  type_handler_version       = "2.73"
  auto_upgrade_minor_version = true

  protected_settings = <<PROTECTED
{
  "properties": {
    "registrationInfoToken": "${azurerm_virtual_desktop_host_pool_registration_info.registration.token}"
  }
}
PROTECTED

  settings = <<SETTINGS
{
  "modulesUrl": "https://wvdportalstorageblob.blob.core.windows.net/galleryartifacts/Configuration_1.0.0.0.zip",
  "configurationFunction": "Configuration.ps1\\AddSessionHost",
  "properties": {
    "hostPoolName": "${azurerm_virtual_desktop_host_pool.host_pool.name}",
    "aadJoin": ${var.intune_join ? "true" : "false"}
  }
}
SETTINGS
}

# AAD Login extension
resource "azurerm_virtual_machine_extension" "aad_login" {
  count                      = var.session_host_count
  name                       = "AADLoginForWindows"
  virtual_machine_id         = azurerm_windows_virtual_machine.confidential_avd[count.index].id
  publisher                  = "Microsoft.Azure.ActiveDirectory"
  type                       = "AADLoginForWindows"
  type_handler_version       = "2.0"
  auto_upgrade_minor_version = true

  depends_on = [
    azurerm_virtual_machine_extension.avd_reg
  ]
}

output "host_pool_id" { value = azurerm_virtual_desktop_host_pool.host_pool.id }
output "workspace_id" { value = azurerm_virtual_desktop_workspace.workspace.id }
output "app_group_id" { value = azurerm_virtual_desktop_application_group.app_group.id }
output "des_id"       { value = var.des_id }
