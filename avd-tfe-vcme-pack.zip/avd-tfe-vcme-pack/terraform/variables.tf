variable "workspace_name"        { type = string }

variable "tenant_id"             { type = string, default = null }
variable "subscription_id"       { type = string }
variable "client_id"             { type = string, default = env("ARM_CLIENT_ID") }
variable "client_secret"         { type = string, sensitive = true, default = env("ARM_CLIENT_SECRET") }

variable "location"              { type = string }
variable "subscription_prefix"   { type = string }
variable "batch"                 { type = string }
variable "target_user_email"     { type = string }

variable "prefix"                { type = string, default = "vcme" }
variable "dr_mode"               { type = bool,   default = true }
variable "hostpool_name"         { type = string, default = "vcmedr" }

variable "image_publisher"       { type = string, default = "microsoftwindowsdesktop" }
variable "image_offer"           { type = string, default = "windows-11" }
variable "image_sku"             { type = string, default = "win11-23h2-ent" }

variable "vm_size"               { type = string, default = "Standard_DC4as_v5" }
variable "session_host_count"    { type = number, default = 1 }

variable "intune_join"           { type = bool,   default = true }

variable "cmk_key_name"          { type = string, default = "cmk-osdisk" }
variable "des_encryption_type"   { type = string, default = "ConfidentialVmEncryptedWithCustomerKey" }

variable "admin_username"        { type = string, default = "avdadmin" }
variable "admin_password"        { type = string, sensitive = true, default = "ChangeM3Now!" }
