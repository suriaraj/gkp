module "naming" {
  source = "./naming"
}

resource "azurerm_resource_group" "rg" {
  name     = module.naming.rg_name
  location = var.location
}

module "vnet" {
  source  = "terraform.xom.cloud/ExxonMobil/virtual-network/azurerm"
  version = "7.0.0"

  location            = var.location
  name                = module.naming.vnet_name
  resource_group_name = azurerm_resource_group.rg.name

  subnets = [{
    name             = module.naming.subnet_name
    address_prefixes = "10.20.1.0/24"
  }]
}

data "azurerm_client_config" "current" {}

# Per-region KV & DES, distinct naming, never destroyed
resource "azurerm_key_vault" "kv" {
  name                        = module.naming.kv_name
  location                    = var.location
  resource_group_name         = azurerm_resource_group.rg.name
  tenant_id                   = data.azurerm_client_config.current.tenant_id
  sku_name                    = "premium"
  purge_protection_enabled    = true
  soft_delete_retention_days  = 90
  enable_rbac_authorization   = false
  enabled_for_disk_encryption = true

  lifecycle {
    prevent_destroy = true
  }
}

resource "azurerm_key_vault_access_policy" "deployer" {
  key_vault_id = azurerm_key_vault.kv.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = data.azurerm_client_config.current.object_id

  key_permissions = [
    "Get","List","Create","Update","Delete","Purge","Recover",
    "Backup","Restore","GetRotationPolicy","SetRotationPolicy"
  ]
}

resource "azurerm_key_vault_key" "cmk" {
  name         = var.cmk_key_name
  key_vault_id = azurerm_key_vault.kv.id
  key_type     = "RSA-HSM"
  key_size     = 2048
  depends_on   = [azurerm_key_vault_access_policy.deployer]

  lifecycle {
    prevent_destroy = true
  }
}

resource "azurerm_disk_encryption_set" "des" {
  name                = module.naming.des_name
  resource_group_name = azurerm_resource_group.rg.name
  location            = var.location
  key_vault_key_id    = azurerm_key_vault_key.cmk.id
  encryption_type     = var.des_encryption_type

  identity {
    type = "SystemAssigned"
  }

  lifecycle {
    prevent_destroy = true
  }
}

resource "azurerm_key_vault_access_policy" "des" {
  key_vault_id = azurerm_key_vault.kv.id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = azurerm_disk_encryption_set.des.identity[0].principal_id

  key_permissions = ["Get","WrapKey","UnwrapKey"]
}

module "avd" {
  source = "./modules/avd"

  prefix              = var.prefix
  dr_mode             = var.dr_mode
  hostpool_name       = var.hostpool_name

  location            = var.location
  resource_group_name = azurerm_resource_group.rg.name
  subscription_id     = var.subscription_id

  subnet_id           = module.vnet.subnet_id[module.naming.subnet_name]
  des_id              = azurerm_disk_encryption_set.des.id

  vm_base             = module.naming.vm_base
  vm_size             = var.vm_size
  session_host_count  = var.session_host_count

  image_publisher     = var.image_publisher
  image_offer         = var.image_offer
  image_sku           = var.image_sku

  intune_join         = var.intune_join
  target_user_email   = var.target_user_email

  admin_username      = var.admin_username
  admin_password      = var.admin_password
}
