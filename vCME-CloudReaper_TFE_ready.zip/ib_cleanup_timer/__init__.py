def main(mytimer):
    pass
