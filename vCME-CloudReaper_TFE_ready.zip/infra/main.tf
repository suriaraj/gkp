variable "subscription_id" {}
variable "tenant_id" {}
variable "resource_group" {}
variable "location" {}
variable "app_settings_file" {}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
  tenant_id       = var.tenant_id
}

locals {
  appsettings = jsondecode(file("${path.module}/appsettings/${var.app_settings_file}"))
  app_settings_merged = merge(
    local.appsettings.settings != null ? local.appsettings.settings : {},
    { FUNCTIONS_WORKER_RUNTIME = "python" }
  )
}

resource "azurerm_resource_group" "rg" {
  name     = var.resource_group
  location = var.location
}

resource "azurerm_storage_account" "sa" {
  name                     = replace(lower("st${var.resource_group}"), "/[^a-z0-9]/", "")
  location                 = var.location
  resource_group_name      = azurerm_resource_group.rg.name
  account_tier             = var.storage_account_tier
  account_replication_type = var.storage_account_replication_type
}

resource "azurerm_service_plan" "plan" {
  name                = "${local.appsettings.function_app_name}-plan"
  resource_group_name = azurerm_resource_group.rg.name
  location            = var.location
  os_type             = var.app_service_os_type
  sku_name            = var.app_service_sku_name
}

resource "azurerm_windows_function_app" "func" {
  name                       = local.appsettings.function_app_name
  resource_group_name        = azurerm_resource_group.rg.name
  location                   = var.location
  service_plan_id            = azurerm_service_plan.plan.id
  storage_account_name       = azurerm_storage_account.sa.name
  storage_account_access_key = azurerm_storage_account.sa.primary_access_key
  functions_extension_version = "~4"

  identity { type = "SystemAssigned" }

  site_config {
    application_stack { python_version = "3.10" }
    always_on = var.always_on
  }

  app_settings = local.app_settings_merged
}

output "function_app_name" {
  value = local.appsettings.function_app_name
}
