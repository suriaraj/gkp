variable "subscription_id" {
  description = "Azure subscription ID"
  type        = string
}

variable "tenant_id" {
  description = "Azure tenant ID"
  type        = string
}

variable "resource_group" {
  description = "Resource group name"
  type        = string
}

variable "location" {
  description = "Azure region (e.g. eastus, centralindia)"
  type        = string
}

variable "app_settings_file" {
  description = "Which appsettings JSON to load (dev.json | qa.json | prod.json)"
  type        = string
}

variable "app_service_sku_name" {
  description = "App Service plan SKU (Y1=Consumption, EP1=Premium, P1v3=Dedicated)"
  type    = string
  default = "Y1"
}

variable "app_service_os_type" {
  description = "OS type: Windows or Linux"
  type        = string
  default     = "Windows"
}

variable "always_on" {
  description = "AlwaysOn setting: true for Premium/Dedicated, false for Consumption"
  type        = bool
  default     = false
}

variable "storage_account_tier" {
  type    = string
  default = "Standard"
}

variable "storage_account_replication_type" {
  type    = string
  default = "LRS"
}
