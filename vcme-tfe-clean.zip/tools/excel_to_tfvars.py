import csv
import json
import logging
import argparse
from pathlib import Path
import secrets
import string

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

def generate_password(length: int = 24) -> str:
    alphabet = string.ascii_letters + string.digits + string.punctuation
    return "".join(secrets.choice(alphabet) for _ in range(length))

def load_region_codes(json_file: str) -> dict:
    with open(json_file) as f:
        region_codes = json.load(f)
    if not isinstance(region_codes, dict):
        raise SystemExit("Region codes JSON must be an object")
    return region_codes

def derive_names(primary_code: str, business_unit: str, dr_loc: str, region_codes: dict) -> dict:
    if dr_loc not in region_codes:
        raise SystemExit(f"{dr_loc} not found in region codes mapping")
    short = region_codes[dr_loc].upper()
    base = f"fVCME-{primary_code.upper()}-{business_unit.upper()}-DR-{short}"
    return {
        "resource_group_name": f"{base}-RG",
        "vnet_name": f"{base}-VN",
        "subnet_name": f"{base}-SN",
        "key_vault_name": f"{base}-KV",
        "des_name": f"{base}-DES"
    }

def generate_tfvars(csv_file: str, output_file: str, region_codes_file: str) -> None:
    region_codes = load_region_codes(region_codes_file)

    with open(csv_file, newline="") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    if not rows:
        raise SystemExit("CSV file is empty or invalid")

    required_cols = [
        "row_id","dr_location","primary_code","business_unit",
        "subscription_alias","subscription_id","vm_prefix",
        "start_index","vm_count","vm_image_id","user_email"
    ]

    def validate_row(row, label):
        for col in required_cols:
            if col not in row or not row[col].strip():
                raise SystemExit(f"Missing required column {col} in {label}")

    deployments = {}
    subscription_ids = {}
    global_vars = {}

    # First row drives shared hostpool/workspace config
    first_row = rows[0]
    validate_row(first_row, "first row")

    dr_loc = first_row["dr_location"].strip().lower()
    primary_code = first_row["primary_code"].strip()
    business_unit = first_row["business_unit"].strip()
    hostpool_subscription_id = first_row["subscription_id"].strip()

    names = derive_names(primary_code, business_unit, dr_loc, region_codes)
    global_vars = {
        "vcme_hostpool_name":      names["vnet_name"].replace("-VN", ""),
        "vcme_hostpool_rg_name":   names["resource_group_name"],
        "vcme_hostpool_location":  dr_loc,
        "vcme_workspace_name":     f"fVCME-{primary_code.upper()}-{business_unit.upper()}-WS",
        "vcme_workspace_rg_name":  f"fVCME-{primary_code.upper()}-{business_unit.upper()}-WS-RG",
        "vcme_workspace_location": dr_loc,
        "hostpool_subscription_id": hostpool_subscription_id,
    }

    # Per-row deployments
    for row in rows:
        validate_row(row, f"row {row.get('row_id','?')}")
        row_id          = row["row_id"].strip()
        dr_loc          = row["dr_location"].strip().lower()
        primary_code    = row["primary_code"].strip()
        business_unit   = row["business_unit"].strip()
        subscription_alias = row["subscription_alias"].strip()
        subscription_id = row["subscription_id"].strip()
        subscription_ids[subscription_alias] = subscription_id

        names = derive_names(primary_code, business_unit, dr_loc, region_codes)

        try:
            start_index = int(row["start_index"])
            vm_count    = int(row["vm_count"])
        except ValueError:
            raise SystemExit(f"Invalid integer values in row {row_id}")

        admin_password = generate_password()

        deployments[row_id] = {
            "subscription_alias":  subscription_alias,
            "subscription_id":     subscription_id,
            "primary_code":        primary_code,
            "business_unit":       business_unit,
            "vm_location":         dr_loc,
            "resource_group_name": names["resource_group_name"],
            "vnet_name":           names["vnet_name"],
            "subnet_name":         names["subnet_name"],
            "key_vault_name":      names["key_vault_name"],
            "des_name":            names["des_name"],
            "vm_prefix":           row["vm_prefix"].strip(),
            "start_index":         start_index,
            "session_host_count":  vm_count,
            "vm_image_id":         row["vm_image_id"].strip(),
            "user_email":          row["user_email"].strip(),
            "admin_password":      admin_password
        }

    global_vars["subscription_ids"] = subscription_ids

    out_path = Path(output_file)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with out_path.open("w", encoding="utf-8") as f:
        # global vars
        for k, v in global_vars.items():
            if isinstance(v, dict):
                f.write(f"{k} = {{
")
                for kk, vv in v.items():
                    f.write(f'  "{kk}" = "{vv}"
')
                f.write("}

")
            else:
                f.write(f'{k} = "{v}"

')

        # deployments map
        f.write("deployments = {
")
        for dk, dv in deployments.items():
            f.write(f'  "{dk}" = {{
')
            for kk, vv in dv.items():
                if isinstance(vv, int):
                    f.write(f"    {kk} = {vv}
")
                else:
                    f.write(f'    {kk} = "{vv}"
')
            f.write("  }
")
        f.write("}
")

    logging.info("HCL tfvars file generated at %s", out_path)

def main():
    parser = argparse.ArgumentParser(description="Generate Terraform tfvars from CSV and region codes")
    parser.add_argument("csv_file", help="Input CSV file path")
    parser.add_argument("output_file", help="Output tfvars file path")
    parser.add_argument("region_codes_file", help="Region codes JSON file path")
    args = parser.parse_args()
    generate_tfvars(args.csv_file, args.output_file, args.region_codes_file)

if __name__ == "__main__":
    main()
