terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.42.0"
    }
  }
}

# Hostpool/workspace subscription provider (default)
provider "azurerm" {
  features {}
  tenant_id       = var.tenant_id
  subscription_id = var.hostpool_subscription_id
}

# MIC subscription provider alias
provider "azurerm" {
  alias    = "mic"
  features {}
  tenant_id       = var.tenant_id
  subscription_id = lookup(var.subscription_ids, "mic", null)
}

# MAE subscription provider alias
provider "azurerm" {
  alias    = "mae"
  features {}
  tenant_id       = var.tenant_id
  subscription_id = lookup(var.subscription_ids, "mae", null)
}
