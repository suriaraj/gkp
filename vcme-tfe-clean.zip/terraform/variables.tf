variable "tenant_id" {
  description = "Azure AD tenant ID"
  type        = string
}

# Shared VCME DR hostpool + workspace
variable "vcme_hostpool_name" {
  type = string
}
variable "vcme_hostpool_rg_name" {
  type = string
}
variable "vcme_hostpool_location" {
  type = string
}
variable "vcme_workspace_name" {
  type = string
}
variable "vcme_workspace_rg_name" {
  type = string
}
variable "vcme_workspace_location" {
  type = string
}

variable "hostpool_subscription_id" {
  description = "Subscription ID hosting the shared VCME DR hostpool/workspace"
  type        = string
}

# Map of subscription alias -> subscription ID loaded from tfvars
variable "subscription_ids" {
  description = "Map of subscription alias -> subscription ID"
  type        = map(string)
}

# Map of deployments, one per CSV row
variable "deployments" {
  description = "Per-row DR deployment config derived from CSV"
  type = map(object({
    subscription_alias  = string
    subscription_id     = string
    primary_code        = string
    business_unit       = string
    vm_location         = string
    resource_group_name = string
    vnet_name           = string
    subnet_name         = string
    key_vault_name      = string
    des_name            = string
    vm_prefix           = string
    start_index         = number
    session_host_count  = number
    vm_image_id         = string
    user_email          = string
    admin_password      = string
  }))
}
