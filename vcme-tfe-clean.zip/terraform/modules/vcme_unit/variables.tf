variable "tenant_id" {
  type = string
}

variable "subscription_id" {
  type = string
}

variable "vm_location" {
  type = string
}

variable "resource_group_name" {
  type = string
}

variable "vnet_name" {
  type = string
}

variable "subnet_name" {
  type = string
}

variable "key_vault_name" {
  type = string
}

variable "des_name" {
  type = string
}

variable "vm_prefix" {
  type = string
}

variable "start_index" {
  type = number
}

variable "session_host_count" {
  type = number
}

variable "vm_image_id" {
  type = string
}

variable "user_email" {
  type = string
}

variable "hostpool_id" {
  type = string
}

variable "registration_token" {
  type = string
}

variable "admin_password" {
  type = string
}
