# VCME DR Terraform + TFE – Clean Template

This is a self-contained **cleaned** template based on your screenshots and our design:
- CSV + Python → `deployments.auto.tfvars`
- Terraform root with:
  - Remote/TFE backend configured via `env/<env>/<region>/backend.tfbackend`
  - Shared VCME DR hostpool/workspace module
  - Per-subscription VCME unit module (one VM set per CSV row)
- GitHub Actions workflow for `dev` / `qa` branches.

You still need to plug in:
- Real `hostname`, `organization`, and workspace names in backend files.
- Real subscription IDs, image IDs, and emails in the CSV.
- Real AVD sizing / settings to match your standards.
