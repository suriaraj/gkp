See ChatGPT message for full validated contents.
