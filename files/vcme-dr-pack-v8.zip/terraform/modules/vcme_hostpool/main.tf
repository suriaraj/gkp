// placeholder module, real contents in chat
