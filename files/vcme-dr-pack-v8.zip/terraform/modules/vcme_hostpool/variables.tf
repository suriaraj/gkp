// placeholder module vars, real contents in chat
