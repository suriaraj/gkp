// placeholder providers, real contents in chat
