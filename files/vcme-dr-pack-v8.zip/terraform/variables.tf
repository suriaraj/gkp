// placeholder variables, real contents in chat
