// placeholder main, real contents in chat
