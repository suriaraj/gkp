terraform {
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm"
      version = "~> 3.116"
    }
    azuread = {
      source = "hashicorp/azuread"
      version = "~> 2.50"
    }
  }
}
provider "azuread" {
  tenant_id = var.tenant_id
}
provider "azurerm" {
  features = {}
  tenant_id = var.tenant_id
  client_id = var.client_id
  client_secret = var.client_secret
  subscription_id = var.hostpool_subscription_id
}