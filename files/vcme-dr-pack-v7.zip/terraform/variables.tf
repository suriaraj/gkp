variable "tenant_id" { type = string }
variable "client_id" { type = string }
variable "client_secret" { type = string, sensitive = true }
variable "hostpool_subscription_id" { type = string }
variable "vcme_hostpool_name" { type = string }
variable "vcme_hostpool_rg_name" { type = string }
variable "vcme_hostpool_location" { type = string }
variable "vcme_workspace_name" { type = string }
variable "vcme_workspace_rg_name" { type = string }
variable "vcme_workspace_location" { type = string }
variable "deployments" {
  description = "Generated from excel_to_tfvars.py"
  type = map(object({
    subscription_id = string
    primary_code = string
    business_unit = string
    vm_location = string
    resource_group_name = string
    vnet_name = string
    subnet_name = string
    key_vault_name = string
    des_name = string
    vm_prefix = string
    start_index = number
    session_host_count = number
    vm_image_id = string
    user_email = string
  }))
}