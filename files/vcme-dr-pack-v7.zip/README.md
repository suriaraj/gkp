# vCME DR Terraform Pack (v7)

This pack automates DR capacity build-out for vCME using:
- One shared VCME DR hostpool + workspace.
- Multiple subscriptions and DR regions (Japan East, SEA, etc).
- Org private registry modules (virtual-network, key-vault, disk-encryption-set, virtual-machine).
- Customer-managed keys (CMK) via DR-specific Key Vault + Disk Encryption Set.
- VM naming like `vCMEMICDR###` / `vCMEMAEDR###` (no '-' in prefix).

## Layout

- `terraform/`
  - `providers.tf` : azurerm + azuread providers.
  - `variables.tf` : shared + per-deployment variables.
  - `main.tf`      : creates shared hostpool/workspace + per-row DR infra and VMs.
  - `modules/`
    - `vcme_hostpool/` : shared hostpool, workspace, app group, registration key.
    - `vcme_unit/`     : RG, VNET, subnet, KV, DES, VCME VMs for each CSV row.
  - `env/<env>/<region>/backend.tfbackend`
    - Example backend config pointing to your TFE hostname/org/workspace.

- `excel/vcme-deployments.csv`
  - Source of truth for DR deployments (no RG/KV/DES names typed).

- `tools/excel_to_tfvars.py`
  - Converts CSV to `deployments.auto.tfvars` with correct DR naming.

- `.github/workflows/vcme-dr.yml`
  - Example reusable workflow: runs `terraform init/plan` with backend config.

## Excel Schema

`excel/vcme-deployments.csv` columns:

- `row_id`          : unique key for the deployment batch.
- `primary_code`    : `MIC` or `MAE` (source prod region).
- `business_unit`   : e.g. `GOS`.
- `dr_location`     : Azure DR region (must be in allowed confidential-compute list).
- `subscription_id` : Subscription where DR VMs will be created.
- `vm_prefix`       : `vCMEMICDR` or `vCMEMAEDR` (no dash).
- `start_index`     : starting VM number (e.g. 1 or 501).
- `vm_count`        : how many VMs to create for this row.
- `vm_image_id`     : full ARM id of VCME image.
- `user_email`      : UPN or group to grant desktop access (per batch).

## Naming Logic (auto-generated)

For each row:
- Base: `vCME-<PRIMARY_CODE>-<BUSINESS>-DR`
- Resource Group: `...-RG`
- VNET:           `...-VN`
- Subnet:         `...-SN`
- Key Vault:      `...-KeyVaults`
- Disk Enc Set:   `...-DES`
- VMs:            `<vm_prefix><N>` (e.g. `vCMEMICDR1` ...)

No need to edit these names in Excel.

## Hostpool & Workspace

- Single DR hostpool/workspace per env (not per region/sub).
- Set via variables:
  - `vcme_hostpool_name`, `vcme_hostpool_rg_name`, `vcme_hostpool_location`
  - `vcme_workspace_name`, `vcme_workspace_rg_name`, `vcme_workspace_location`
  - `hostpool_subscription_id` (static subscription that owns hostpool/ws)
- Module `vcme_hostpool`:
  - Creates or reuses hostpool, workspace, app group.
  - Exposes `hostpool_id` + `registration_token`.
- Module `vcme_unit`:
  - Uses that token to register DR VMs into the same hostpool.
  - Assumes **direct / personal** assignment model.

## Allowed DR Locations

`tools/excel_to_tfvars.py` enforces `dr_location` to be one of your CC-supported regions.
Adjust the `CONF_COMP_LOCATIONS` set if your approved list changes.

## How to Run (manual flow)

1. Update `excel/vcme-deployments.csv` with your DR scenario.
2. Generate tfvars:
   ```bash
   python tools/excel_to_tfvars.py excel/vcme-deployments.csv terraform/env/dev/jpn/deployments.auto.tfvars
   ```
3. Update `terraform/env/dev/jpn/backend.tfbackend`:
   - Set correct `hostname`, `organization`, and workspace `name` (must end with `ws`).
4. From repo root:
   ```bash
   cd terraform/env/dev/jpn
   terraform init -backend-config=backend.tfbackend
   terraform plan
   terraform apply
   ```

For QA/Prod:
- Duplicate env folders (`env/qa/...`, `env/prod/...`) with their own backend.tfbackend.
- Use different CSV rows or tfvars as needed.