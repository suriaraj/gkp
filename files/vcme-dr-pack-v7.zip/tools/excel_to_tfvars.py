import csv, sys
from pathlib import Path
CONF_COMP_LOCATIONS = {"japaneast","southeastasia","eastasia","westeurope","northeurope","germanywestcentral"}
def derive_names(primary_code,business_unit):
    base=f"vCME-{primary_code.upper()}-{business_unit.upper()}-DR"
    return {"resource_group_name":f"{base}-RG","vnet_name":f"{base}-VN","subnet_name":f"{base}-SN","key_vault_name":f"{base}-KeyVaults","des_name":f"{base}-DES"}
def main(csv_file,output_file):
    deployments={}
    with open(csv_file) as f:
        r=csv.DictReader(f)
        for row in r:
            dr_loc=row["dr_location"].strip().lower()
            if dr_loc not in CONF_COMP_LOCATIONS: raise SystemExit(f"{dr_loc} not approved.")
            names=derive_names(row["primary_code"],row["business_unit"])
            deployments[row["row_id"]]={"subscription_id":row["subscription_id"],"primary_code":row["primary_code"],"business_unit":row["business_unit"],"vm_location":dr_loc,**names,"vm_prefix":row["vm_prefix"],"start_index":int(row["start_index"]),"session_host_count":int(row["vm_count"]),"vm_image_id":row["vm_image_id"],"user_email":row["user_email"]}
    Path(output_file).parent.mkdir(parents=True,exist_ok=True)
    with open(output_file,"w") as f:
        f.write("deployments = {\n")
        for k,v in deployments.items():
            f.write(f"  {k} = {{\n")
            for kk,vv in v.items(): f.write(f'    {kk} = "{vv}"\n' if isinstance(vv,str) else f"    {kk} = {vv}\n")
            f.write("  }\n")
        f.write("}\n")
if __name__=="__main__":
    if len(sys.argv)!=3: print("Usage: excel_to_tfvars.py <input.csv> <output.tfvars>"); sys.exit(1)
    main(sys.argv[1],sys.argv[2])