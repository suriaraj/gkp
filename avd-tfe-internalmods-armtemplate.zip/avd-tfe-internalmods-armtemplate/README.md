# AVD + TFE CI/CD (internal modules + ARM) — NO workspace prefix

- Workspace name == `name` from Excel/CSV (no prefix).
- Names:
  - RG: `vcme-<locShort>-dr-rg`
  - VNet: `vcme-<locShort>-vn`
  - Subnet: `sn`
  - VM: `vcme<locShort>DR`
  - Host pool: default `vcmedr` (override per target)
- Uses private registry modules (virtual-network, key-vault, disk-encryption-set).
- Session host VM via ARM template at `terraform/arm/avd-sessionhost.json`.
