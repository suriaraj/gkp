module "naming" {
  source = "./naming"
}

resource "azurerm_resource_group" "rg" {
  name     = module.naming.rg_name
  location = var.location
}

module "vnet" {
  source  = "terraform.xom.cloud/ExxonMobil/virtual-network/azurerm"
  version = "7.0.0"

  location            = var.location
  name                = module.naming.vnet_name
  resource_group_name = azurerm_resource_group.rg.name

  subnets = [{
    name             = module.naming.subnet_name
    address_prefixes = "10.20.1.0/24"
  }]
}

module "kv" {
  source  = "terraform.xom.cloud/ExxonMobil/key-vault/azurerm"
  version = "8.0.2"

  location            = var.location
  name                = coalesce(var.cmk_kv_name, "${var.prefix}-${module.naming.loc_short}-kv")
  resource_group_name = azurerm_resource_group.rg.name

  enabled_for_disk_encryption = true
  purge_protection_enabled    = true
  rbac_authorization_enabled  = false
}

module "des" {
  source  = "terraform.xom.cloud/ExxonMobil/disk-encryption-set/azurerm"
  version = "1.0.1"

  location            = var.location
  name                = "${var.prefix}-${module.naming.loc_short}-des"
  resource_group_name = azurerm_resource_group.rg.name
}

module "avd" {
  source = "./modules/avd"

  prefix          = var.prefix
  dr_mode         = var.dr_mode
  hostpool_name   = var.hostpool_name

  location        = var.location
  subscription_id = var.subscription_id
  target_user_email = var.target_user_email

  image_publisher = var.image_publisher
  image_offer     = var.image_offer
  image_sku       = var.image_sku
  intune_join     = var.intune_join

  resource_group_name = azurerm_resource_group.rg.name
  subnet_id           = module.vnet.subnet_id[module.naming.subnet_name]
  des_id              = module.des.disk_encryption_set_id
}
