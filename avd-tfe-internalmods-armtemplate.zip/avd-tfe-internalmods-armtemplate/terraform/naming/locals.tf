locals {
  loc_short_map = {
    "japan_east"    = "jpn"
    "japan_west"    = "jpw"
    "westeurope"    = "weu"
    "northeurope"   = "neu"
    "eastus"        = "eus"
    "eastus2"       = "eus2"
    "westus3"       = "wus3"
    "uksouth"       = "uks"
    "southeastasia" = "sea"
  }
  loc_norm    = lower(replace(var.location, " ", ""))
  loc_short   = lookup(local.loc_short_map, loc_norm, loc_norm)
  dr_suffix   = var.dr_mode ? "-dr" : ""
  rg_name     = "${var.prefix}-$${local.loc_short}${dr_suffix}-rg"
  vnet_name   = "${var.prefix}-$${local.loc_short}-vn"
  subnet_name = "sn"
  vm_base     = "${var.prefix}${local.loc_short}${var.dr_mode ? "DR" : ""}"
}

output "loc_short" { value = local.loc_short }
output "rg_name"   { value = local.rg_name }
output "vnet_name" { value = local.vnet_name }
output "subnet_name" { value = local.subnet_name }
output "vm_base"   { value = local.vm_base }
