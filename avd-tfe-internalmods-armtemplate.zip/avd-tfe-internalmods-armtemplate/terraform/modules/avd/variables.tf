variable "prefix"        { type = string }
variable "dr_mode"       { type = bool }
variable "hostpool_name" { type = string }

variable "location"            { type = string }
variable "resource_group_name" { type = string }

variable "subscription_id"   { type = string }
variable "target_user_email" { type = string }

variable "subnet_id"         { type = string }
variable "des_id"            { type = string }

variable "image_publisher" { type = string }
variable "image_offer"     { type = string }
variable "image_sku"       { type = string }

variable "intune_join"     { type = bool }
variable "session_host_count" { type = number, default = 1 }
variable "vm_size"            { type = string, default = "Standard_DC4as_v5" }
