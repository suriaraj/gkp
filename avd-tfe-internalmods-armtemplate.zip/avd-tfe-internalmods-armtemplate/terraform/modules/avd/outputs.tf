output "host_pool_id"   { value = azurerm_virtual_desktop_host_pool.hp.id }
output "workspace_id"   { value = azurerm_virtual_desktop_workspace.ws.id }
output "app_group_id"   { value = azurerm_virtual_desktop_application_group.dag.id }
