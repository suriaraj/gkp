data "azurerm_client_config" "current" {}

locals {
  loc_short_map = {
    "japan_east"    = "jpn"
    "japan_west"    = "jpw"
    "westeurope"    = "weu"
    "northeurope"   = "neu"
    "eastus"        = "eus"
    "eastus2"       = "eus2"
    "westus3"       = "wus3"
    "uksouth"       = "uks"
    "southeastasia" = "sea"
  }
  loc_norm  = lower(replace(var.location, " ", ""))
  loc_short = lookup(local.loc_short_map, local.loc_norm, local.loc_norm)
  vm_base   = "${var.prefix}${local.loc_short}${var.dr_mode ? "DR" : ""}"
}

resource "azurerm_virtual_desktop_host_pool" "hp" {
  name                = var.hostpool_name
  location            = var.location
  resource_group_name = var.resource_group_name
  type                       = "Pooled"
  load_balancer_type         = "BreadthFirst"
  preferred_app_group_type   = "Desktop"
  maximum_sessions_allowed   = 16
  validate_environment       = true
  start_vm_on_connect        = true
}

resource "azurerm_virtual_desktop_host_pool_registration_info" "reg" {
  hostpool_id     = azurerm_virtual_desktop_host_pool.hp.id
  expiration_date = timeadd(timestamp(), "24h")
}

resource "azurerm_virtual_desktop_application_group" "dag" {
  name                = "${var.prefix}-${local.loc_short}-dag"
  location            = var.location
  resource_group_name = var.resource_group_name
  type                = "Desktop"
  host_pool_id        = azurerm_virtual_desktop_host_pool.hp.id
}

resource "azurerm_virtual_desktop_workspace" "ws" {
  name                = "${var.prefix}-${local.loc_short}-ws"
  location            = var.location
  resource_group_name = var.resource_group_name
}

resource "azurerm_virtual_desktop_workspace_application_group_association" "assoc" {
  workspace_id         = azurerm_virtual_desktop_workspace.ws.id
  application_group_id = azurerm_virtual_desktop_application_group.dag.id
}

data "azuread_user" "target" {
  user_principal_name = var.target_user_email
}

data "azurerm_role_definition" "dv_user" {
  name  = "Desktop Virtualization User"
  scope = azurerm_virtual_desktop_application_group.dag.id
}

resource "azurerm_role_assignment" "grant" {
  scope              = azurerm_virtual_desktop_application_group.dag.id
  role_definition_id = data.azurerm_role_definition.dv_user.role_definition_id
  principal_id       = data.azuread_user.target.object_id
  principal_type     = "User"
}

resource "azurerm_network_interface" "nic" {
  count               = var.session_host_count
  name                = "${local.vm_base}-nic-${count.index}"
  location            = var.location
  resource_group_name = var.resource_group_name

  ip_configuration {
    name                          = "ipconfig1"
    subnet_id                     = var.subnet_id
    private_ip_address_allocation = "Dynamic"
  }
}

resource "azurerm_resource_group_template_deployment" "sessionhosts" {
  name                = "avd-sessionhosts"
  resource_group_name = var.resource_group_name
  deployment_mode     = "Incremental"

  template_content = file("${path.module}/../arm/avd-sessionhost.json")

  parameters_content = jsonencode({
    location = { value = var.location }
    vmName   = { value = local.vm_base }
    vmSize   = { value = var.vm_size }
    subnetId = { value = var.subnet_id }
    desId    = { value = var.des_id }
    image = {
      value = {
        publisher = var.image_publisher
        offer     = var.image_offer
        sku       = var.image_sku
        version   = "latest"
      }
    }
    hostPoolRegistrationToken = { value = azurerm_virtual_desktop_host_pool_registration_info.reg.token }
    intuneJoin = { value = var.intune_join }
  })
}
