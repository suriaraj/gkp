output "workspace_name" { value = var.workspace_name }
output "rg_name"        { value = module.naming.rg_name }
output "vnet_name"      { value = module.naming.vnet_name }
output "vm_base"        { value = module.naming.vm_base }
output "host_pool_id"   { value = module.avd.host_pool_id }
output "workspace_id"   { value = module.avd.workspace_id }
output "app_group_id"   { value = module.avd.app_group_id }
output "disk_encryption_set_id" { value = module.des.disk_encryption_set_id }
